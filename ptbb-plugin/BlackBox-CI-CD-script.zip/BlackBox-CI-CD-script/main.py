from blackbox_ci.blackbox_ci import main

if __name__ == '__main__':
    main()
